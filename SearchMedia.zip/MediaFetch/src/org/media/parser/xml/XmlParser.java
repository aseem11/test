package org.media.parser.xml;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.media.parser.Parser;
import org.media.parser.exception.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sun.xml.internal.messaging.saaj.util.ByteInputStream;

public class XmlParser implements Parser
{

    @Override
    public Map < String, Object > parseResponse ( String response ) throws ParseException
    {
        Map < String, Object > responseMap = null;
        if ( response != null )
        {
            responseMap = new HashMap < String, Object > ( );
            try
            {
                Object value = null;
                // Creating the XPath object.
                XPath xPath = XPathFactory.newInstance ( ).newXPath ( );
                // Creating the Document object from the XML response.
                Document xmlContent = createXmlDocument ( response );
                // Searching for the node with the results.
                Node node = ( Node ) xPath.compile ( "//albummatches" ).evaluate ( xmlContent, XPathConstants.NODE );
                NodeList nodeList = node.getChildNodes ( );
                if ( nodeList.getLength ( ) > 0 )
                {
                    List < Map < String, Object > > resultList = new ArrayList < Map < String, Object > > ( );
                    int ctr = 0;
                    Map < String, Object > childMap = null;
                    while ( ctr < nodeList.getLength ( ) )
                    {
                        childMap = new HashMap < String, Object > ( );
                        childMap.put ( "name", nodeList.item ( ctr ).getChildNodes ( ).item ( 0 ).getTextContent ( ) );
                        childMap.put ( "artist", nodeList.item ( ctr ).getChildNodes ( ).item ( 1 ).getTextContent ( ) );
                        resultList.add ( childMap );
                        ctr++;
                    }
                    value = resultList;
                }
                responseMap.put ( "albummatches", value );
            }
            catch ( XPathExpressionException e )
            {
                throw new ParseException ( e );
            }
        }
        return responseMap;
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to create XML doc from response string.
     * @param response : String.
     * @return Document.
     * @throws ParseException.
     * </pre>
     */
    private Document createXmlDocument ( String response ) throws ParseException
    {
        Document doc = null;
        try
        {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance ( );
            // This will ensure no namespace is considered. Just simple XML.
            docBuilderFactory.setNamespaceAware ( Boolean.FALSE );
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder ( );
            InputSource inputSource =
                new InputSource ( new ByteInputStream ( response.getBytes ( ), response.getBytes ( ).length ) );
            doc = docBuilder.parse ( inputSource );
            doc.getDocumentElement ( ).normalize ( );
        }
        catch ( ParserConfigurationException | SAXException | IOException e )
        {
            throw new ParseException ( e );
        }

        return doc;
    }
}
