package org.media.parser.json;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.media.parser.Parser;
import org.media.parser.exception.ParseException;

public class JsonParser implements Parser
{

    @Override
    public Map < String, Object > parseResponse ( String response ) throws ParseException
    {
        Map < String, Object > respMap = null;
        if ( response != null )
        {
            try
            {
                // Simplying the response by breaking down various expressions.
                Map < String, Object > expressionMap = new HashMap < String, Object > ( );
                expressionMap.put ( "CTR", 1 );
                expressionMap = simplifyResponse ( response, expressionMap );
                // Extracting the key-value pairs from the simplfied string and creating a map.
                respMap =
                    extractKeyValue ( ( String ) expressionMap.get ( "RESPONSE" ), new HashMap < String, Object > ( ),
                        expressionMap );
            }
            catch ( Exception e )
            {
                throw new ParseException ( e );
            }
        }
        return respMap;
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to simplify the response provided by replacing the lists with placeholders and
     * adding them to a map for later evaluation.
     * @param response : String.
     * @param expressionMap : Map < String, Object >.
     * @return
     * </pre>
     */
    private Map < String, Object > simplifyResponse ( String response, Map < String, Object > expressionMap )
    {
        String simplifiedResponse = response;
        if ( response != null )
        {
            if ( response.contains ( "[" ) )
            {
                Integer ctr = ( Integer ) expressionMap.get ( "CTR" );
                Boolean continueProcessing = Boolean.FALSE;
                int openBracketIndex = response.indexOf ( "[" );
                String tempResp = response.substring ( openBracketIndex + 1 );
                // Finding next open bracket and end bracket.
                int nextOpenBracketIndex = tempResp.indexOf ( "[" );
                int endBracketIndex = tempResp.indexOf ( "]" );
                // If open bracket is before end bracket, then there is nesting.
                if ( nextOpenBracketIndex != -1 && nextOpenBracketIndex < endBracketIndex )
                {
                    // Invoking the simplification of nesting.
                    expressionMap = simplifyResponse ( tempResp, expressionMap );
                    // The sub response will have simplified value.
                    String subTempResp = ( String ) expressionMap.get ( "RESPONSE" );
                    // Replacing this in the main response.
                    response = response.replace ( tempResp, subTempResp );
                    // Temp response now becomes the simplified response.
                    tempResp = subTempResp;
                    // Resetting the end bracket index as the value has changed.
                    endBracketIndex = tempResp.indexOf ( "]" );
                    // Resetting the counter.
                    ctr = ( Integer ) expressionMap.get ( "CTR" );
                    continueProcessing = Boolean.TRUE;
                }
                else
                {
                    continueProcessing = Boolean.TRUE;
                }
                if ( continueProcessing )
                {
                    // If not, then it means we have only one set to take care of.
                    tempResp = "[" + tempResp.substring ( 0, endBracketIndex + 1 );
                    // Add the set to the map.
                    expressionMap.put ( "###K" + ctr, tempResp );
                    // Replace the expression in response with key.
                    simplifiedResponse = response.replace ( tempResp, "###K" + ctr );
                    // Add response to map.
                    expressionMap.put ( "RESPONSE", simplifiedResponse );
                    ++ctr;
                    expressionMap.put ( "CTR", ctr );
                    expressionMap = simplifyResponse ( simplifiedResponse, expressionMap );
                }
            }
        }
        return expressionMap;
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to extract the key value pairs (map) based on the simplified response.
     * @param response : String.
     * @param responseMap : Map < String, Object >.
     * @param expressionMap : Map < String, Object >.
     * @return Map < String, Object >.
     * </pre>
     */
    private Map < String, Object > extractKeyValue ( String response, Map < String, Object > responseMap,
                                                     Map < String, Object > expressionMap )
    {
        if ( response != null )
        {
            String key = null;
            String val = null;
            String leftResp = null;
            int startIndex = 0;
            String endChar = ",\"";
            // Checking if the response is a set of key values.
            if ( response.startsWith ( "{" ) )
            {
                startIndex = 1;
            }
            // If comma is not found in the string that means it is the last key-value pair in the array.
            if ( response.indexOf ( ",\"" ) == -1 )
            {
                endChar = "}";
            }
            // Extracting the key-value pair by splitting the on ":".
            String keyVal = response.substring ( startIndex, response.indexOf ( endChar ) );
            key = keyVal.substring ( 0, keyVal.indexOf ( "\":" ) + 1 ).replace ( "\"", "" );
            val = keyVal.substring ( keyVal.indexOf ( "\":" ) + 2 );
            Object value = null;
            // Checking if the value is an array of sets. Then handle it separately.
            if ( val.startsWith ( "###" ) && expressionMap.containsKey ( val ) )
            {
                // Checking if it is a list of values or a list of maps.
                String expressionValue = ( String ) expressionMap.get ( val );
                if ( !expressionValue.equals ( "[]" ) )
                {
                    if ( expressionValue.contains ( ":" ) )
                    {
                        List < Map < String, Object > > respMapList = extractMaps ( expressionValue, expressionMap );
                        value = respMapList;
                    }
                    else
                    {
                        List < String > respList = extractList ( expressionValue );
                        value = respList;
                    }
                }
            }
            else
            {
                if ( val != null && val.startsWith ( "\"" ) )
                {
                    value = val.substring ( 1, val.lastIndexOf ( "\"" ) );
                }
                else
                {
                    value = val;
                }
            }
            // Adding value to map.
            responseMap.put ( key, value );
            // If the end char is still comma, that means there is further key-value pairs left in the response. Parse
            // those.
            if ( ",\"".equals ( endChar ) )
            {
                leftResp = response.substring ( response.indexOf ( endChar ) + 1 );
                responseMap = extractKeyValue ( leftResp, responseMap, expressionMap );
            }
        }
        return responseMap;
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to extract list from the expression provided.
     * @param expressionValue : String.
     * @return List < String >.
     * </pre>
     */
    private List < String > extractList ( String expressionValue )
    {
        List < String > valList = null;
        if ( expressionValue != null )
        {
            valList = Arrays.asList ( expressionValue.replace ( "[", "" ).replace ( "]", "" ).split ( "," ) );
        }
        return valList;
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to extract the List of Maps provided in the response.
     * @param response : String.
     * @param expressionMap : Map < String, Object >.
     * @return List < Map < String, Object > >.
     * </pre>
     */
    private List < Map < String, Object > > extractMaps ( String response, Map < String, Object > expressionMap )
    {
        List < Map < String, Object > > respMapList = new ArrayList < Map < String, Object > > ( );
        if ( response != null )
        {
            String remainingResp = response;
            if ( !remainingResp.trim ( ).equals ( "[]" ) )
            {
                int startIndex = 0;
                int endIndex = 0;
                String endChar = "},";
                Map < String, Object > respMap = null;
                while ( remainingResp.length ( ) > 0 )
                {
                    // If comma is not found in the string that means it is the last key-value pair in the array.
                    if ( remainingResp.indexOf ( "}," ) == -1 )
                    {
                        endChar = "]";
                        endIndex = remainingResp.indexOf ( "]" );
                        if ( remainingResp.startsWith ( "[" ) )
                        {
                            startIndex = 1;
                        }
                        else
                        {
                            startIndex = 0;
                        }
                    }
                    else
                    {
                        endIndex = remainingResp.indexOf ( "}," ) + 1;
                    }
                    String keyValueSet = remainingResp.substring ( startIndex, endIndex );
                    respMap = new HashMap < String, Object > ( );
                    respMap = extractKeyValue ( keyValueSet, respMap, expressionMap );
                    if ( respMap != null )
                    {
                        respMapList.add ( respMap );
                    }

                    // If the end char is still brace+comma, that means there is further key-value pairs left in the
                    // response. Parse those.
                    if ( "},".equals ( endChar ) )
                    {
                        remainingResp = remainingResp.substring ( remainingResp.indexOf ( endChar ) + 2 );
                    }
                    else
                    {
                        remainingResp = "";
                    }
                }
            }
        }
        return respMapList;
    }
}
