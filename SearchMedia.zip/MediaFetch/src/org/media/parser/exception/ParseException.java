package org.media.parser.exception;

public class ParseException extends Exception
{

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Creates the ParseException.
     * @param e : Throwable.
     * </pre>
     */
    public ParseException ( Throwable e )
    {
        super ( e );
    }

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

}
