package org.media.parser;

import java.util.Map;

import org.media.parser.exception.ParseException;

public interface Parser
{

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to parse the response.
     * @param response : String.
     * @return Map < String, Object >.
     * @throws ParseException.
     * </pre>
     */
    public Map < String, Object > parseResponse ( String response ) throws ParseException;
}
