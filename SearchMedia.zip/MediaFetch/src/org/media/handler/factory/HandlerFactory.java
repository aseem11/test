package org.media.handler.factory;

import org.media.handler.Handler;
import org.media.handler.MovieHandler;
import org.media.handler.MusicHandler;

public class HandlerFactory
{

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to get the Handler object based on the media type provided.
     * @param mediaType : String.
     * @return Handler.
     * </pre>
     */
    public Handler getHandler ( String mediaType )
    {
        Handler handler = null;
        if ( mediaType != null )
        {
            if ( "movie".equalsIgnoreCase ( mediaType ) )
            {
                handler = new MovieHandler ( );
            }
            else if ( "music".equalsIgnoreCase ( mediaType ) )
            {
                handler = new MusicHandler ( );
            }
        }
        return handler;
    }
}
