package org.media.handler;

public interface Handler
{

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to be implemented to handle the request and 
     * search for data based on the search keyword provided.
     * @param searchKeyword : String.
     * </pre>
     */
    public void handleRequest ( String searchKeyword, String apiKey );
}
