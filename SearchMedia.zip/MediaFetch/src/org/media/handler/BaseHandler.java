package org.media.handler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import org.media.parser.Parser;
import org.media.parser.exception.ParseException;

public abstract class BaseHandler implements Handler
{

    /**
     * The URL which will be used for conducting the search.
     */
    protected String searchAPI = null;

    /**
     * The instance of the Parser.
     */
    private Parser parser = null;

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Creates the BaseHandler.
     * @param searchAPI : String.
     * @param parser : Parser.
     * </pre>
     */
    public BaseHandler ( String searchAPI, Parser parser )
    {
        this.searchAPI = searchAPI;
        this.parser = parser;
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to be implemented to handle the request and 
     * search for data based on the search keyword provided.
     * @param searchKeyword : String.
     * </pre>
     */
    @Override
    public void handleRequest ( String searchKeyword, String apiKey )
    {
        HttpURLConnection connection = null;
        BufferedReader bufferedReader = null;
        try
        {
            // Making the search request.
            // Establishing connection and sending the request.
            URL url = new URL ( getSearchURL ( searchKeyword, apiKey ) );
            connection = ( HttpURLConnection ) url.openConnection ( );
            connection.setRequestMethod ( "GET" );

            // Reading the response.
            bufferedReader = new BufferedReader ( new InputStreamReader ( connection.getInputStream ( ) ) );
            // Getting the response string.
            StringBuffer response = new StringBuffer ( );

            // Getting response from the InputStream.
            String line = bufferedReader.readLine ( );
            while ( line != null )
            {
                response.append ( line );
                line = bufferedReader.readLine ( );
            }

            // Process the response.
            processResponse ( response.toString ( ) );
        }
        catch ( IOException e )
        {
            // This block is to handle exception related to connections, etc.
            if ( e.getMessage ( ) != null &&
                ( e.getMessage ( ).contains ( "response code: 401" ) || e.getMessage ( ).contains (
                    "response code: 403" ) ) )
            {
                System.out.println ( "Invalid API Key provided. Try again with valid key." );
            }
            else
            {
                System.out.println ( "Could not establish connection. Please try after sometime." );
            }
        }
        catch ( ParseException e )
        {
            // This block is invoked for unknown response parsing exceptions. This block should never be used but this
            // is a safety net.
            System.out.println ( "Something went wrong. Please try after sometime." );
        }
        catch ( Exception e )
        {
            // This block is to handle unknown exceptions. This block should never be used but this is a safety net.
            System.out.println ( "Something went wrong. Please try after sometime." );
        }
        finally
        {
            // Closing the reader.
            if ( bufferedReader != null )
            {
                try
                {
                    bufferedReader.close ( );
                }
                catch ( IOException e )
                {
                    // Do nothing
                }
            }
            // Closing connection.
            if ( connection != null )
            {
                connection.disconnect ( );
            }
        }
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to get the search URL.
     * Each child class needs to: 
     * 1. Decide its own URL.
     * 2. Decide on how to treat the search keyword entered.
     * @param searchKeyword : String.
     * @param apiKey : String.
     * @return String.
     * </pre>
     */
    protected abstract String getSearchURL ( String searchKeyword, String apiKey );

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to invoke the parser and then show the output.
     * @param response : String
     * @throws ParseException.
     * </pre>
     */
    @SuppressWarnings ( "unchecked" )
    private void processResponse ( String response ) throws ParseException
    {
        // Parsing the JSON response.
        Map < String, Object > responseMap = parser.parseResponse ( response );

        // Checking for the main result set.
        if ( responseMap != null && responseMap.containsKey ( getResultKey ( ) ) )
        {
            // Checking if the result is received.
            Object resultObj = responseMap.get ( getResultKey ( ) );
            if ( resultObj != null )
            {
                // If yes, then iterating and showing the results.
                List < Map < String, Object > > resultList = ( List < Map < String, Object >> ) resultObj;
                if ( !resultList.isEmpty ( ) )
                {
                    StringBuffer recordDisplay = null;
                    int ctr = 0;
                    // Constructing the output header.
                    StringBuffer boxLines = displayOutputHeader ( );
                    // Iterating the result set and displaying the output.
                    for ( Map < String, Object > result : resultList )
                    {
                        recordDisplay = new StringBuffer ( );
                        ctr = 0;
                        for ( String displayKey : getDisplayKeys ( ) )
                        {
                            if ( ctr == ( getDisplayKeys ( ).size ( ) - 1 ) )
                            {
                                recordDisplay.append ( getFormattedString ( ( String ) result.get ( displayKey ), " ",
                                    getFieldLength ( displayKey ), Boolean.FALSE, Boolean.TRUE ) );
                            }
                            else
                            {
                                recordDisplay.append ( getFormattedString ( ( String ) result.get ( displayKey ), " ",
                                    getFieldLength ( displayKey ), Boolean.FALSE, Boolean.FALSE ) );
                            }
                            ctr++;
                        }
                        System.out.println ( recordDisplay.toString ( ) );
                    }
                    // Closing the table.
                    System.out.println ( boxLines.toString ( ) );
                }
                else
                {
                    System.out.println ( "No match found. Please try a different search." );
                }
            }
            else
            {
                System.out.println ( "No match found. Please try a different search." );
            }
        }
        else
        {
            System.out.println ( "No match found. Please try a different search." );
        }
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to get the key which will have the required result set.
     * @return String.
     * </pre>
     */
    protected abstract String getResultKey ( );

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to get the keys whose values need to be displayed.
     * @return List < String >.
     * </pre>
     */
    protected abstract List < String > getDisplayKeys ( );

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to construct the header for the result.
     * @return StringBuffer.
     * </pre>
     */
    private StringBuffer displayOutputHeader ( )
    {
        List < String > displayKeys = getDisplayKeys ( );
        StringBuffer boxLines = new StringBuffer ( );
        StringBuffer headerText = new StringBuffer ( );
        int ctr = 0;
        int totalColumnWidth = 0;
        for ( String key : displayKeys )
        {
            // Constructing the header for the table.
            if ( ctr == ( displayKeys.size ( ) - 1 ) )
            {
                boxLines.append ( getFormattedString ( "-", "-", getFieldLength ( key ), Boolean.TRUE, Boolean.TRUE ) );
                headerText.append ( getFormattedString ( getFieldName ( key ), " ", getFieldLength ( key ),
                    Boolean.FALSE, Boolean.TRUE ) );
            }
            else
            {
                boxLines.append ( getFormattedString ( "-", "-", getFieldLength ( key ), Boolean.TRUE, Boolean.FALSE ) );
                headerText.append ( getFormattedString ( getFieldName ( key ), " ", getFieldLength ( key ),
                    Boolean.FALSE, Boolean.FALSE ) );
            }
            totalColumnWidth += getFieldLength ( key );
            ctr++;
        }
        // Adding the courtesy text.
        if ( getCourtesyText ( ) != null )
        {
            System.out.println ( boxLines.toString ( ) );
            System.out.println ( getFormattedString ( getCourtesyText ( ), " ", totalColumnWidth + ctr, Boolean.FALSE,
                Boolean.TRUE ) );
        }
        // Displaying the header.
        System.out.println ( boxLines.toString ( ) );
        System.out.println ( headerText.toString ( ) );
        System.out.println ( boxLines.toString ( ) );
        return boxLines;
    }

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to get the desired length of the field based on the key.
     * @param key : String.
     * @return int.
     * </pre>
     */
    protected abstract int getFieldLength ( String key );

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to get the desired name of the field based on the key.
     * @param key : String.
     * @return String.
     * </pre>
     */
    protected abstract String getFieldName ( String key );

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to get the courtsey text.
     * @return String.
     * </pre>
     */
    protected abstract String getCourtesyText ( );

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Method to get the formatted string.
     * @param text : String.
     * @param formatChar : String.
     * @param length : int.
     * @param isBoxLine : Boolean.
     * @param isLastColumn : Boolean.
     * @return String.
     * </pre>
     */
    private String getFormattedString ( String text, String formatChar, int length, Boolean isBoxLine,
                                        Boolean isLastColumn )
    {
        StringBuffer formattedText = new StringBuffer ( );
        int extraSize = 1;
        formattedText.append ( "|" );
        // If regular text, then add space in the beginning.
        if ( !isBoxLine )
        {
            text = " " + text;
        }

        if ( isLastColumn )
        {
            // Incrementing as another pipe at the end will be added.
            extraSize++;
        }
        formattedText.append ( text );
        for ( int i = 0; i < ( length - ( text.length ( ) - extraSize ) ); i++ )
        {
            formattedText.append ( formatChar );
        }
        // Adding end of column pipe.
        if ( isLastColumn )
        {
            formattedText.append ( "|" );
        }
        return formattedText.toString ( );
    }
}
