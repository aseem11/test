package org.media.handler;

import java.util.Arrays;
import java.util.List;

import org.media.parser.json.JsonParser;

public class MovieHandler extends BaseHandler
{

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Creates the MovieHandler.
     * </pre>
     */
    public MovieHandler ( )
    {
        super ( "https://api.themoviedb.org/3/search/movie?api_key=", new JsonParser ( ) );
    }

    @Override
    protected String getSearchURL ( String searchKeyword, String apiKey )
    {
        return searchAPI + apiKey + "&query=" + searchKeyword.replace ( " ", "+" );
    }

    @Override
    protected String getResultKey ( )
    {
        return "results";
    }

    @Override
    protected List < String > getDisplayKeys ( )
    {
        return Arrays.asList ( "title", "release_date" );
    }

    @Override
    protected int getFieldLength ( String key )
    {
        int fieldLength = 12;
        if ( key != null )
        {
            switch ( key )
            {
            case "title":
                fieldLength = 90;
                break;
            }
        }
        return fieldLength;
    }

    @Override
    protected String getFieldName ( String key )
    {
        String fieldName = "";
        if ( key != null )
        {
            switch ( key )
            {
            case "title":
                fieldName = "Movie Title";
                break;
            case "release_date":
                fieldName = "Release Date";
                break;
            }
        }
        return fieldName;
    }

    @Override
    protected String getCourtesyText ( )
    {
        return "Data courtesy TMDB (The Movie Database) API";
    }

}
