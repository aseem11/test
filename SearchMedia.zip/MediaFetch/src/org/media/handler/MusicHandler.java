package org.media.handler;

import java.util.Arrays;
import java.util.List;

import org.media.parser.xml.XmlParser;

public class MusicHandler extends BaseHandler
{

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Creates the MusicHandler.
     * </pre>
     */
    public MusicHandler ( )
    {
        super ( "http://ws.audioscrobbler.com/2.0/?method=album.search&api_key=", new XmlParser ( ) );
    }

    @Override
    protected String getSearchURL ( String searchKeyword, String apiKey )
    {
        return searchAPI + apiKey + "&album=" + searchKeyword.replace ( " ", "+" );
    }

    @Override
    protected String getResultKey ( )
    {
        return "albummatches";
    }

    @Override
    protected List < String > getDisplayKeys ( )
    {
        return Arrays.asList ( "name", "artist" );
    }

    @Override
    protected int getFieldLength ( String key )
    {
        int fieldLength = 50;
        if ( key != null )
        {
            switch ( key )
            {
            case "name":
                fieldLength = 90;
                break;
            }
        }
        return fieldLength;
    }

    @Override
    protected String getFieldName ( String key )
    {
        String fieldName = "";
        if ( key != null )
        {
            switch ( key )
            {
            case "name":
                fieldName = "Album Name";
                break;
            case "artist":
                fieldName = "Artist";
                break;
            }
        }
        return fieldName;
    }

    @Override
    protected String getCourtesyText ( )
    {
        return "Data courtesy Last.fm API";
    }

}
