package org.media;

import org.media.handler.Handler;
import org.media.handler.factory.HandlerFactory;

public class SearchMedia
{

    /**
     * <pre>
     * <b>Description : </b> <br>
     * Main method. Entry point into the program.
     * @param args : String [].
     * </pre>
     */
    public static void main ( String[ ] args )
    {
        // Checking for valid parameters.
        if ( args.length != 3 )
        {
            System.out.println ( "Invalid parameters. Use the format <media_type> <search_keyword> <api_key> in the that order. media_type can only be movie or music. Eg: movie \"Jack Reacher\" 4xdg565e41567a67783de55wwa4a2734" );
        }
        else
        {
            // If provided, then check for valid media type.
            if ( !args[0].equalsIgnoreCase ( "movie" ) && !args[0].equalsIgnoreCase ( "music" ) )
            {
                System.out.println ( "Invalid Media Type. Media Type can only be movie or music." );
            }
            else
            {
                // Getting the required handler.
                Handler handler = new HandlerFactory ( ).getHandler ( args[0] );
                // Processing the request.
                handler.handleRequest ( args[1], args[2] );
            }
        }
    }
}
